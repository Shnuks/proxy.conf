<footer class="container pt-4 my-md-5 pt-md-5 border-top"></footer>
    <div class="row">
      <div class="col-12 col-md">
        <small class="d-block mb-3 text-muted">© 2023–2028</small>
      </div>
      <div class="col-6 col-md">
        <h5>Контакты:</h5>
        <ul class="list-unstyled text-small">
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">support@sysahelper.ru</a></li>
          <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">admin@sysahelper.ru</a></li>
        </ul>
      </div>
    </div>
</footer>
